<?php

	var_dump($_POST);
?>