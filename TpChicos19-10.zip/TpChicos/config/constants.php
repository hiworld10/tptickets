<?php 
namespace config;

	/*define("ROOT", str_replace('\\', '/', dirname(__DIR__)) . '/');*/
	
	
 ?>